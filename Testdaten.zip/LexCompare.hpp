#include "Wort.hpp"

class LexCompare
{
	public: 
	bool operator()(const Wort& w1, const Wort& w2) const ;
	
	private:
	static bool compare(char c1, char c2) ;
} ;
