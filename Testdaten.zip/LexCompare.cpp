#include <algorithm>
#include <cctype>

#include "Wort.hpp"
#include "LexCompare.hpp"

// Vergleichsfunktion ohne Beruecksichtigung von Gross- und Kleinschreibung :
bool LexCompare::compare (char c1, char c2)
{ 
	return tolower(c1) < tolower(c2) ; 
}

bool LexCompare::operator()(const Wort& w1, const Wort& w2) const
{
	return lexicographical_compare(w1.begin(), w1.end(), w2.begin(), w2.end(), compare) ;
} 